

function applyCursorStyle() {
    let prevCell = document.getElementById('prevCell');
    let nextCell = document.getElementById('nextCell');
    // Проверяем, не пуст ли элемент prevCell
    if (prevCell.innerHTML.trim() !== '') {
        // Если элемент не пустой, добавляем класс для стилизации курсора
        prevCell.classList.add('cursor-pointer');
    } else {
        // Если элемент пустой, удаляем класс
        prevCell.classList.remove('cursor-pointer');
    }

    if (nextCell.innerHTML.trim() !== '') {
        // Если элемент не пустой, добавляем класс для стилизации курсора
        nextCell.classList.add('cursor-pointer');
    } else {
        // Если элемент пустой, удаляем класс
        nextCell.classList.remove('cursor-pointer');
    }
}

window.onload = function() {
    var secondCellText = document.querySelectorAll('table')[1].querySelector('td:nth-child(2)').innerText;
    var parts = secondCellText.split('/');
    var pageNow = parts[0].trim();
    var pageLast = parts[1].trim();
    var prevCell = document.getElementById('prevCell');
    var nextCell = document.getElementById('nextCell');
    var prevImage = document.createElement('img');
    var nextImage = document.createElement('img');

    prevImage.src = '/static/images/prev.png';
    prevImage.alt = 'ПредСтраница';
    prevImage.width = 50;
    prevImage.height = 50;

    nextImage.src = '/static/images/next.png';
    nextImage.alt = 'СледСтраница';
    nextImage.width = 50;
    nextImage.height = 50;

    if (pageNow !== '1' && prevCell.childElementCount === 0) {
        prevCell.appendChild(prevImage);

    }
    else if (pageNow === '1') {
        prevCell.textContent = '';
    }

    if (pageNow !== pageLast && nextCell.childElementCount === 0) {
        nextCell.appendChild(nextImage);

    }
    else if (pageNow === pageLast) {
        nextCell.textContent = '';
    }
    applyCursorStyle()
};

document.getElementById('prevCell').addEventListener('click', function() {
    var text = document.querySelectorAll('table')[1].querySelector('td:nth-child(2)').innerText;
    var numerator = parseInt(text.split('/')[0]);
    if (numerator > 1) {
        window.location.href = 'http://localhost:8888/homepage/page_' + String(numerator - 1)
    }
});

document.getElementById('nextCell').addEventListener('click', function() {
    var text = document.querySelectorAll('table')[1].querySelector('td:nth-child(2)').innerText;
    var numerator = parseInt(text.split('/')[0]);
    var denominator = parseInt(text.split('/')[1]);
    if (numerator < denominator) {
        window.location.href = 'http://localhost:8888/homepage/page_' + String(numerator + 1)
    }
});
